import{l as o,a as r}from"../chunks/Baykk5sG.js";export{o as load_css,r as start};
